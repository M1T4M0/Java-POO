/**
 * 
 */
/**
 * 
 */
module Laboratorio1cort1 {
}